This Program contains both my hardcoded version and a using loop to fix that problem ,that i thought of it later.

This is my first time coding kotlin so...it's a little bit rough.